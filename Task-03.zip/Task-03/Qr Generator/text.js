// Select elements
const generateBtn = document.getElementById('generate-btn');
const textInput = document.getElementById('text-input');
const qrCodeContainer = document.getElementById('qrcode');

// Function to generate QR code
generateBtn.addEventListener('click', () => {
    const text = textInput.value;
    
    if (text === "") {
        alert("Please enter a valid text or URL");
        return;
    }
    
    // Clear the previous QR code if it exists
    qrCodeContainer.innerHTML = "";

    // Generate new QR code
    const qrCode = new QRCode(qrCodeContainer, {
        text: text,
        width: 200,
        height: 200
    });
});
